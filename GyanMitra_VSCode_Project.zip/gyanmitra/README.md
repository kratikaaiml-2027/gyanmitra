# GyanMitra: AI Tutor for Rural Students (SDG 4)

Features: Ask a Doubt (Hindi/English), Quiz generator, Progress and weak-topic tracker.

## Run in VS Code (Windows)
1. Install Python 3.10+ (tick "Add to PATH") and VS Code with the Python extension.
2. File > Open Folder > select this `gyanmitra` folder.
3. Open the terminal (Ctrl + `) and run:
       python -m venv .venv
       .venv\Scripts\activate
       pip install -r requirements.txt
4. (Optional, for real AI) copy `.env.example` to `.env` and paste your free Gemini key.
   Without a key the app runs in Demo mode with sample answers.
5. Run:  streamlit run app.py     (or press F5 in VS Code)

Mac/Linux: use `python3 -m venv .venv` and `source .venv/bin/activate`.

## Deploy (for the review link)
Push to GitHub (the .env file is ignored), then at share.streamlit.io create an app
with main file `app.py` and add `GEMINI_API_KEY = "your_key"` under Advanced settings > Secrets.

## Files
- app.py: user interface and three features
- ai.py: all AI calls and demo mode (edit only this to switch AI provider)
